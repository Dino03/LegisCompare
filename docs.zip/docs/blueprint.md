# **App Name**: Legislate Compare

## Core Features:

- Bill Input: Allow users to input the congress number (e.g., 18th, 19th), and the bill number, then the app will pull the data from the official government website. The bill input should also allow searching for keywords of the bill or resolution title.
- AI Bill Summarization: Use AI to generate summaries of each bill, highlighting key provisions and potential impacts. This includes understanding the context and purpose of each bill.
- AI Bill Comparison: Employ an AI tool to compare and contrast the bills, identifying similarities, differences, and potential conflicts. The AI tool will use reasoning to decide whether any overlaps may exist between any provisions.
- AI Regulatory Impact Assessment: The AI tool will determine whether there might be an impact on the SEC's regulations and create a draft comment for each comparison.
- Summary Display: Present the bill summaries and comparison results in a clear, structured format, making it easy to understand the analysis.
- Comment Management: Provide a user-friendly interface to review, edit, and export the draft comments.

## Style Guidelines:

- Primary color: Dark Blue (#34495E) to evoke a sense of trust and professionalism.
- Background color: Light gray (#F0F3F4), for a clean, neutral backdrop.
- Accent color: Teal (#2ECC71), used to highlight key insights and actions.
- Headline font: 'Poppins', sans-serif. Body text: 'Inter', sans-serif; creating a balance of modernity and readability.
- Use simple, professional icons to represent bill categories and actions.
- Employ a clean and structured layout, with clear visual hierarchy to guide the user through the bill analysis.
- Use subtle transitions and animations to provide feedback and enhance user engagement.